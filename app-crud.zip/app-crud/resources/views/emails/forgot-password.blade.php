<h1>Reset Password</h1>
<a href="{{ route('reset.password', $token) }}">Reset Password</a>
