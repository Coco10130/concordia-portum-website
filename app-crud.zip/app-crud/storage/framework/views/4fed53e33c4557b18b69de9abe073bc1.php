

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="/css/profile.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-5">
        <div class="col-2 mt-5 d-flex align-items-center" style="height: 70vh">
            <div class="navigation">
                <ul>
                    <a href="/profile" class="<?php echo e(Request::is('profile') ? 'active' : ''); ?> profile">My Profile</a>
                </ul>
                <ul>
                    <a href="/my-purchases" class="<?php echo e(Request::is('my-purchases') ? 'active' : ''); ?> my-purchase">My Purchase</a>
                </ul>
                <ul>
                    <a href="/my-shop" class="<?php echo e(Request::is('my-shop') ? 'active' : ''); ?> my-shop">My Shop</a>
                </ul>
            </div>
        </div>

        <div class="col-9 mt-5">
            <?php echo $__env->make('shared.my-shop-card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success text-center mt-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>

    <?php if($user->is_seller): ?>
        <div class="container-fluid d-flex justify-content-center align-items-center"  >
            <div class="row  d-flex justify-content-center align-items-center">
                <div class="col">
                    <?php if($products->isEmpty()): ?>
                        <p class="mt-4 text col d-flex justify-content-center align-items-center h4" style="margin-bottom: 50px;">No products available</p>
                    <?php else: ?>
                        <?php echo $__env->make('shared.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php $__errorArgs = ['productName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/my-shop.blade.php ENDPATH**/ ?>