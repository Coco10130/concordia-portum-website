<div class="row mt-3 mb-5">
    <div class="col-9">
    </div>
    <div class="col-3">
        <div class="card cart-totals">
            <div class="card-body">
                <div class="row d-flex align-items-center justify-content-between">
                    <div class="col-6 text-left">Subtotal:</div>
                    <div class="col-6 text-right">₱<span id="subtotal-value">0.00</span></div>
                </div>
                <div class="row d-flex align-items-center justify-content-between">
                    <div class="col-6 text-left">Tax:</div>
                    <div class="col-6 text-right">₱<span id="tax-value">0.00</span></div>
                </div>
                <div class="row d-flex align-items-center justify-content-between">
                    <div class="col-6 text-left">Total:</div>
                    <div class="col-6 text-right">₱<span id="total-value">0.00</span></div>
                </div>
                <div class="row d-flex align-items-center justify-content-between">
                    <div class="col-6 text-left">Total Items:</div>
                    <div class="col-6 text-right">₱<span id="total-items-value">0</span></div>
                </div>
                <a href="#" class="btn btn-primary mt-3">Checkout</a>
            </div>
        </div>
    </div>
</div>

<script>
    // Function to update the total
    function updateTotal() {
        let subtotal = 0;
        let totalItems = 0;
        const checkboxes = document.querySelectorAll('.select input[type="checkbox"]:checked');
        for (const checkbox of checkboxes) {
            const price = parseFloat(checkbox.closest('.product-col').querySelector('.product-price').textContent.slice(
                1));
            const quantity = parseInt(checkbox.closest('.product-col').querySelector('.quantity-text').textContent);
            subtotal += price * quantity;
            totalItems += quantity;
        }

        // Update subtotal
        const subtotalElement = document.getElementById('subtotal-value');
        subtotalElement.textContent = subtotal.toFixed(2);

        // Calculate tax (example: 10% tax)
        const tax = subtotal * 0.1; // You can replace 0.1 with your tax rate
        const taxElement = document.getElementById('tax-value');
        taxElement.textContent = tax.toFixed(2);

        // Update total
        const totalElement = document.getElementById('total-value');
        const total = subtotal + tax;
        totalElement.textContent = total.toFixed(2);

        // Update total items
        const totalItemsElement = document.getElementById('total-items-value');
        totalItemsElement.textContent = totalItems;
    }

    // Add event listeners to all checkboxes
    const checkboxes = document.querySelectorAll('.select input[type="checkbox"]');
    checkboxes.forEach(checkbox => checkbox.addEventListener('change', updateTotal));

    // Trigger initial calculation
    updateTotal();
</script>

<?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/layouts/cart-total.blade.php ENDPATH**/ ?>