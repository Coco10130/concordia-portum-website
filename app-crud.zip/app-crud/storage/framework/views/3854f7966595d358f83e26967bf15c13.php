

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="/css/verifyemail.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card w-50 mx-auto p-4">
        <h1 class="text-center mb-5" style="font-family: 'Kavoon', cursive;">Verify your Email</h1>
        <p>Please enter the 6 digit code sent to your email address.</p>
        

        <?php echo $__env->make('auth.verify-code', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.forgot-pass-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/verify-code.blade.php ENDPATH**/ ?>