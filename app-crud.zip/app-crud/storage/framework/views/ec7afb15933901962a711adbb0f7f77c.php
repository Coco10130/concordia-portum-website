<form action="" method="POST">
    <?php echo csrf_field(); ?>
    <label for="imageInput" class="upload-btn">
        Change Image
        <input type="file" id="imageInput" accept="image/*" onchange="uploadImage()"
            aria-label="Upload Image">
    </label>
</form><?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/shared/edit-profile-pic.blade.php ENDPATH**/ ?>