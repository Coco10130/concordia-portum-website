<form action="<?php echo e(route('profile.update', ['profile' => Auth::id()])); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="container-fluid placeholderss" style="padding: 20px;">
        <div class="row">
            <div class="col">
                <p class="my-profile h2 mt-4">My Profile</p>
            </div>
        </div>

        <div class="row mt-5">
            <div class="col-3 d-flex justify-content-center align-items-center">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col d-flex justify-content-center align-items-center">
                            <div class="profile-image">
                                <?php if(isset($user->image) && $user->image != ''): ?>
                                    <img src="<?php echo e(asset($user->image)); ?>" alt="Profile" id="profileImage">
                                <?php else: ?>
                                    <img src="/images/default-picture.png" alt="Profile" id="profileImage">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col mt-2 d-flex justify-content-center align-items-center">

                            <div class="change-profile">
                                
                                <label for="imageInput" class="upload-btn"  style="border: 1px solid #000000">
                                    Change Image
                                    <input type="file" id="imageInput" name="image" accept="image/*">
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            
            <div class="col-8">
                <div class="row mt-5">
                    <div class="col-4 d-flex justify-content-center align-items-center">
                        <p class="user-name">Username:</p>
                    </div>
                    <div class="col d-flex justify-content-start align-items-center">
                        <p class="user-name"><?php echo e($user->userName); ?></p>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-4 d-flex justify-content-center align-items-center">
                        <p class="user-name">Email:</p>
                    </div>
                    <div class="col d-flex justify-content-start align-items-center">
                        <p class="user-name"><?php echo e($user->email); ?></p>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-4 d-flex justify-content-center align-items-center">
                        <p class="user-name">Phone Number:</p>
                    </div>
                    <div class="col d-flex justify-content-start align-items-center">
                        <?php if(!$user->phoneNumber): ?>
                            <input type="price_number" class="form-control <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="phoneNumber">
                            <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php else: ?>
                            <p class="user-name"><?php echo e($user->phoneNumber); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-4 d-flex justify-content-center align-items-center">
                        <p class="user-name">Address:</p>
                    </div>
                    <div class="col d-flex justify-content-start align-items-center">
                        <?php if(!$user->address): ?>
                            <input type="price_number" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="address">
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php else: ?>
                            <p class="user-name"><?php echo e($user->address); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-4 d-flex justify-content-center align-items-center">
                        <p class="user-name">Gender:</p>
                    </div>
                    <div class="col d-flex justify-content-start align-items-center">
                        <?php if(!$user->gender): ?>
                            <div class="col-2">
                                <div class="form-check">
                                    <input class="form-check-input <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="radio"
                                        name="gender" value="male" id="male">
                                    <label class="form-check-label" for="male">
                                        Male
                                    </label>
                                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" value="female"
                                        id="female">
                                    <label class="form-check-label" for="female">
                                        Female
                                    </label>
                                </div>
                            </div>
                    </div>
                <?php else: ?>
                    <p class="user-name mt-1"><?php echo e($user->gender); ?></p>
                    <?php endif; ?>
                </div>

                <div class="row mt-3">
                    <div class="col-4 d-flex justify-content-center align-items-center">
                        <p class="user-name">Birthday:</p>
                    </div>
                    <div class="col d-flex justify-content-start align-items-center">
                        <?php if(!$user->birthDate): ?>
                            <input type="date" class="form-control <?php $__errorArgs = ['birthDay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="birthday" name="birthDate" max="<?php echo e(date('Y-m-d')); ?>">
                            <?php $__errorArgs = ['birthDay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php else: ?>
                            <p class="user-name mt-1"><?php echo e($user->birthDate); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-11">
                        <div class="form-floating d-flex justify-content-end">
                            <input type="submit" name="submit" class="btn btn-outline-secondary" value="Save">
                            <label for="remember-me" class="text-dark"></label>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</form>

<script>
    function displayImage(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                document.querySelector('.profile-image img').src = e.target.result;
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    document.getElementById('imageInput').addEventListener('change', function() {
        displayImage(this);
    });
</script>


<style>
    .navigation-col,
    .test {
        border: 1px solid blue;
    }

    .navigation a {
        color: rgb(0, 0, 0);
        text-decoration: none;
        transition: color 0.3s ease-in-out;
    }

    .navigation ul {
        margin: 30px 0px;
    }

    .placeholderss {
        background-color: #ffffff;
        border-radius: 30px;
    }

    .profile-image img {
        height: 100px;
        width: 100px;
        border-radius: 50px;
    }

    .upload-btn {
        display: inline-block;
        padding: 10px;
        color: #000000;
        background-color: #fff;
        cursor: pointer;
        border-radius: 15px;
    }

    .upload-btn input {
        display: none;
    }

    .upload-btn input::before {
        content: "";
        display: none;
    }

    .my-profile {
        margin-left: 40px;
    }

    .upload-btn {
        padding: 15px 15px;
        font-size: 13px;
    }

    .btn {
        padding: 8px 28px;
    }

    .input-group input,
    .input-group-text,
    .form-check {
        font-size: 14px;
    }

    .navigation ul a,
    .my-profile,
    .upload-btn,
    .input-group input,
    .input-group-text,
    .form-check {
        font-family: 'oswald';
    }

    .user-name,
    .upload-btn,
    .btn {
        font-family: 'poppins';
    }

    .navigation ul a:hover {
        color: #fff;
        background-color: #3eb489;
    }

    .navigation ul a {
        transition: .3s ease-in-out;
        border-radius: 30px;
        padding: 6px 6px;
    }

    .my-profile {
        border-bottom: 2px solid rgb(0, 0, 0);
        width: 90%;
    }

    .navigation a[href="/profile"].active,
    .navigation a[href="/profile"]:hover,
    .navigation a[href="/my-shop"].active,
    .navigation a[href="/my-shop"]:hover,
    .navigation a[href="/my-purchases"].active,
    .navigation a[href="/my-purchases"]:hover {
        color: #fff;
        background-color: #3eb489;
    }
</style>
<?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/shared/edit-profile.blade.php ENDPATH**/ ?>