<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<form action="<?php echo e(route('forgot.password')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col">
            <div class="form-floating mb-3 text-center">
                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingEmail" placeholder=" " name="email">
                <label class="form-label-custom" for="floatingEmail">Email Address</label>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-end">
        <a href="/login">
            <button type="button" class="btn text btn-outline-secondary"
                style="color: #fffbfb; text-decoration: none;">Cancel</button>
        </a>
        <div style="margin-left: 10px;"></div>
        <input type="submit" class="btn text btn-outline-light" value="Send Verification Code" name="submit">
        <label for="remember-me" class="text-dark"></label>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/auth/enter-email.blade.php ENDPATH**/ ?>