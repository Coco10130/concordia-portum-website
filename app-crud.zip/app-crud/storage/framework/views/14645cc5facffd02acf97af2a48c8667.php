

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="/css/purchase.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-5">
        <div class="col-2 mt-5 d-flex align-items-center" style="height: 70vh">
            <div class="navigation">
                <ul>
                    <a href="/profile" class="<?php echo e(Request::is('profile') ? 'active' : ''); ?> profile">My Profile</a>
                </ul>
                <ul>
                    <a href="/my-purchases" class="<?php echo e(Request::is('my-purchases') ? 'active' : ''); ?> my-purchase">My Purchase</a>
                </ul>
                <ul>
                    <a href="/my-shop" class="<?php echo e(Request::is('my-shop') ? 'active' : ''); ?> my-shop">My Shop</a>
                </ul>
            </div>
        </div>

        <div class="col-9 mt-5">
            <?php echo $__env->make('shared.my-purchase-card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/my-purchases.blade.php ENDPATH**/ ?>