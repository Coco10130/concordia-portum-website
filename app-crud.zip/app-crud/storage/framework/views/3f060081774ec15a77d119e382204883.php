<form action="<?php echo e(route('cart.remove-items')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <input type="hidden" name="product_ids[]" value="<?php echo e($item->product_id); ?>">
    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
</form><?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/shared/remove-from-cart.blade.php ENDPATH**/ ?>