<ul class="nav flex-column m-0">
    <li class="nav-item">
        <a class="nav-link text <?php echo e($category == 'violin' ? 'active' : ''); ?>" href="<?php echo e(route('products.index', ['category' => 'violin'])); ?>">Violin</a>
    </li>
    <li class="nav-item">
        <a class="nav-link text <?php echo e($category == 'trumpet' ? 'active' : ''); ?>" href="<?php echo e(route('products.index', ['category' => 'trumpet'])); ?>">Trumpet</a>
    </li>
    <li class="nav-item">
        <a class="nav-link text <?php echo e($category == 'saxophone' ? 'active' : ''); ?>" href="<?php echo e(route('products.index', ['category' => 'saxophone'])); ?>">Saxophone</a>
    </li>
    <li class="nav-item">
        <a class="nav-link text <?php echo e($category == 'piano' ? 'active' : ''); ?>" href="<?php echo e(route('products.index', ['category' => 'piano'])); ?>">Piano</a>
    </li>
    <li class="nav-item">
        <a class="nav-link text <?php echo e($category == 'clarinet' ? 'active' : ''); ?>" href="<?php echo e(route('products.index', ['category' => 'clarinet'])); ?>">Clarinet</a>
    </li>
</ul>
<?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/shared/category-nav.blade.php ENDPATH**/ ?>