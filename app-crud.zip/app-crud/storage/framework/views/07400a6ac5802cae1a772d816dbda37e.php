<footer class="fixed-bottom bg-light d-flex justify-content-center align-items-center">
    <p>Concordia Portum</p>
</footer><?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/layouts/footer.blade.php ENDPATH**/ ?>