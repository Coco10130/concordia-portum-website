<h1>Reset Password</h1>
<a href="<?php echo e(route('reset.password', $token)); ?>">Reset Password</a>
<?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/emails/forgot-password.blade.php ENDPATH**/ ?>