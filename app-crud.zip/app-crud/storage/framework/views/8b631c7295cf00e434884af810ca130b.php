<div class="container-fluid placeholders" style="padding: 20px;">
    <div class="row">
        <div class="col">
            <p class="my-profile h2 mt-4">My Shop</p>
        </div>
    </div>
    <?php if($user->is_seller): ?>
        <div class="row mt-5">
            <div class="col-1 d-flex justify-content-center align-items-center">
                <div class="container-fluid">
                    
                </div>
            </div>


            
            <div class="col-4">
                <div class="container-fluid">
                    <div class="row mt-5">
                        <div class="col d-flex justify-content-end align-items-center">
                            <p class="user-name">Shop Name:</p>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col d-flex justify-content-end align-items-center">
                            <p class="user-name">Shop Email:</p>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col d-flex justify-content-end align-items-center">
                            <p class="user-name">Shop Phone Number:</p>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-5 mb-3 d-flex justify-content-start align-items-center">
                
                <?php echo $__env->make('shared.shop-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <div class="row-mt5">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <?php echo $__env->make('shared.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    <?php else: ?>
        <p class="btn-holder mt-5 d-flex justify-content-center align-items-center"> <a href="/register-seller"
                class="btn btn-outline-secondary">
                Register as Seller
            </a>
        </p>
    <?php endif; ?>



</div><?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/shared/my-shop-card.blade.php ENDPATH**/ ?>