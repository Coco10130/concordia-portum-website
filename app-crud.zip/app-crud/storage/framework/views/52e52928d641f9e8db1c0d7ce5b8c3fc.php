<div class="row product-row mt-5">
    <div class="col d-flex justify-content-center">
        <div class="row d-flex justify-content-between align-items-center mb-5">
            <?php if($products->isEmpty()): ?>
                <div class="col d-flex justify-content-center align-items-center">No products available</div>
            <?php else: ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($index % 3 == 0): ?>
                        <div class="col"></div>
                        <div class="w-100"></div>
                    <?php endif; ?>
                    <div class="col-4 mt-5">
                        <div class="card product-card" style="width: 283px">
                            <img src="<?php echo e(asset($product->image)); ?>" class="card-img-top"
                                alt="Product Image">
                            <div class="card-body">
                                <p class="price"><?php echo e($product->seller->shop_name); ?></p>
                                <h5 class="card-title product-name"><?php echo e($product->product_name); ?></h5>
                                <h6 class="price">₱<?php echo e(number_format($product->price, 2)); ?></h6>
                                <div class="btn-group mt-3" role="group" aria-label="Product Actions">
                                    <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-primary">Edit</a>
                                    <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/shared/products.blade.php ENDPATH**/ ?>