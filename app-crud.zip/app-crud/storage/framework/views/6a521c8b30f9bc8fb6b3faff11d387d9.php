<?php if($products->isEmpty()): ?>
    <div class="col price h3 d-flex justify-content-center align-items-center">No products available</div>
<?php else: ?>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($index % 3 == 0): ?>
            <div class="col"></div>
            <div class="w-100"></div>
        <?php endif; ?>

        <div class="col-4 mt-5 prod-col">
            <div class="card product-card" style="width: 283px">
                <img src="<?php echo e(asset($product->image)); ?>" class="card-img-top" alt="Product Image">
                <div class="card-body" style="border-top: 1px solid rgb(0, 0, 0)">
                    <div class="d-flex justify-content-between">
                        <p class="price"><?php echo e($product->seller->shop_name); ?></p>
                        <p class="price">Stock: <?php echo e($product->quantity); ?></p>
                    </div>
                    <h5 class="card-title product-name"><?php echo e($product->product_name); ?></h5>
                    <h6 class="price">₱<?php echo e(number_format($product->price, 2)); ?></h6>
                    <form action="<?php echo e(route('productsAddToCart', $product->id)); ?>" method="POST"
                        class="d-flex align-items-center justify-content-between align-items-center">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn text btn-outline-secondary mt-3">Add to cart</button>
                        <div class="form-group form-quantity">
                            <label for="quantity">Quantity:</label>
                            <input type="number" name="quantity" id="quantity" value="1" min="1"
                                max="<?php echo e($product->quantity); ?>" class="form-control quantity-input" required>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/categories/Clarinet.blade.php ENDPATH**/ ?>