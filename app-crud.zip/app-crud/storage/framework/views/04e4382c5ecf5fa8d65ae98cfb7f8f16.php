

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="/css/createnewpass.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="cardd w-40 mx-auto p-4">
        <h1 class="text-center mb-5" style="font-family: 'oswald'; color: #ffffff;">Create your New Password</h1>
        <p style="color: #ffffff; font-family: 'oswald';">Your new password must be different from previously used password.</p>

        <?php echo $__env->make('auth.create-new-password', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.forgot-pass-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/create-new-password.blade.php ENDPATH**/ ?>