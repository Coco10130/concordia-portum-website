<form method="POST" action="<?php echo e(route('products.store')); ?>" enctype="multipart/form-data" class="d-flex justify-content-center align-items-center">
    <?php echo csrf_field(); ?>

    <input type="file" name="image" accept="image/*" required>
    <input type="text" name="product_name" placeholder="Product Name" required>
    <input type="number" name="price" placeholder="Price" required>

    <button type="submit">Submit</button>
</form>
<?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/layouts/create.blade.php ENDPATH**/ ?>