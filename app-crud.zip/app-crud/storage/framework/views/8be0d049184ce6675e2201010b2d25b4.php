

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="/css/checkOut.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-5" style="margin-left: 30px">
        <div class="col-12 mt-5 d-flex align-items-center">
            <div class="container placeholders">
                <div class="row">
                    <div class="col mb-2">
                        <div class="address d-flex align-items-between">
                            <img src="/images/address.png" alt="">
                            <p class="delivery-tag h4">Delivery Address</p>
                        </div>
                    </div>
                </div>

                <div class="row bottom-row">
                    <div class="col" style="margin: 0 40px">
                        <?php if($user->address && $user->phoneNumber): ?>
                        <div class="address d-flex justify-content-between">
                            <p class="user-address h5"><?php echo e($user->address); ?> </p>
                            <p class="user-address h5"><?php echo e($user->phoneNumber); ?> </p>
                        </div>
                        <?php else: ?>
                            <p class="user-address h5">No Address</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row mt-4">
                    <div class="col">
                        <p class="product-tag h4">Product Ordered</p>
                    </div>
                </div>
                <?php if($user->address): ?>
                    <form id="placeOrderForm" action="<?php echo e(route('place.order')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <?php $__currentLoopData = $groupedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shopName => $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row mt-3">
                                <div class="col-6">
                                    <div class="shop mt-2 d-flex align-items-between">
                                        <img src="/images/shop-icon.png" alt="">
                                        <p class="shopName-label"><?php echo e($shopName); ?></p>
                                    </div>
                                </div>

                                <div class="col-2 ">
                                    <p class="unit-label">Price</p>
                                </div>

                                <div class="col-2 ">
                                    <p class="quantity-label">Quantity</p>
                                </div>

                                <div class="col-2 ">
                                    <p class="subtotal-label">Subtotal</p>
                                </div>
                            </div>



                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row bottom-row">
                                    <div class="col-6">
                                        <div class="product d-flex align-items-center">
                                            <img src="<?php echo e(asset($product->image)); ?>" alt="Product Image">
                                            <p class="product-name"><?php echo e($product->product_name); ?></p>
                                        </div>
                                    </div>
                                    <div class="col-2 d-flex justify-content-start align-items-center">
                                        <p class="price">₱ <?php echo e(number_format($product->price, 2)); ?></p>
                                    </div>
                                    <div class="col-2 d-flex justify-content-start align-items-center">
                                        <p class="quantity">
                                            <?php $__currentLoopData = $product->carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($cart->quantity); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </p>
                                    </div>
                                    <div class="col-2 d-flex justify-content-start align-items-center">
                                        <p class="subtotal">₱ <?php echo e(number_format($product->price * $cart->quantity, 2)); ?></p>
                                    </div>
                                </div>
                                <input type="hidden" name="product_ids[]" value="<?php echo e($product->id); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <div class="row bottom-row mt-2">
                            <div class="col-3 d-flex align-items-center">
                                <p class="shipping-tag h5"><b>Shipping Option</b></p>
                            </div>
                            <div class="col-3 text-center d-flex justify-content-center align-items-center">
                                <?php
                                $maxDeliveryDate = date('d M', strtotime('+5 days'));
                                $minDeliveryDate = date('d M', strtotime('+3 days'));
                                ?>
                                <p class="shipping-option">Standard Shipping <br> Get by <?php echo e($minDeliveryDate); ?> -
                                    <?php echo e($maxDeliveryDate); ?></p>
                            </div>
                            <div class="col-3 text-center d-flex justify-content-center align-items-center">
                                <p class="shipping-fee">₱ <?php echo e(number_format($shippingFee, 2)); ?></p>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-3 ">
                                <p class="payment-tag h5"><b>Payment Method</b></p>
                            </div>
                            <div class="col-3 text-center d-flex justify-content-center align-items-center">
                                <p class="payment-method">Cash on Delivery</p>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col">
                                <p class="payment-details"><b>Payment Details</b></p>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-4">
                                <div class="row">
                                    <div class="col-9 text-left">Merchandise Subtotal</div>
                                    <div class="col-3 text-right">₱ <?php echo e(number_format($merchandiseSubtotal, 2)); ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-9 text-left">Shipping Fee</div>
                                    <div class="col-3 text-right">₱ <?php echo e(number_format($shippingFee, 2)); ?></div>
                                </div>
                            </div>

                            <div class="col-4">
                                <div class="row">
                                    <div class="col-9 text-left">Discount:</div>
                                    <div class="col-3 text-right">10%</div>
                                </div>
                                <div class="row">
                                    <div class="col-9 text-left">Total Payment</div>
                                    <div class="col-3 text-right">₱ <?php echo e(number_format($totalPayment, 2)); ?></div>
                                </div>
                            </div>

                            <div class="col-2">
                                
                            </div>

                            <div class="col-2 d-flex justify-content-center align-items-center">
                                <button type="submit" class="btn btn-outline-secondary">Place Order</button>
                            </div>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="alert alert-danger text-center mt-3" role="alert">
                        Please provide a delivery address before placing an order.
                    </div>
                    <a href="<?php echo e(route('profile.index')); ?>" class="btn btn-outline-secondary ml-2">Go to Profile</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/check-out.blade.php ENDPATH**/ ?>