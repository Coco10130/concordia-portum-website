<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<form action="<?php echo e(route('verify.code')); ?>" method="POST" enctype="multipart/form-data">

    <?php echo csrf_field(); ?>

    <div class="row">
        <div class="col">
            <div class="form-floating mb-3 text-center">
                <input type="text" name="token" class="form-control" id="fourDigitCode" maxlength="6">
                <label for="fourDigitCode">Code</label>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-end">
        <a href="<?php echo e(route('forgot.password.view')); ?>">
            <button type="button" class="btn btn-outline-secondary">Cancel</button>
        </a>
        <div style="margin-left: 10px;"></div>
        <button type="submit" class="btn btn-outline-secondary">Verify</button>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/auth/verify-code.blade.php ENDPATH**/ ?>