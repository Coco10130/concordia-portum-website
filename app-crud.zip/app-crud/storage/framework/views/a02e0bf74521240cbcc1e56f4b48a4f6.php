<?php $__env->startSection('content'); ?>
    <div class="row align-items-center justify-content-center">
        <div class="col-10">
            <?php echo $__env->make('layouts.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="row">
        <div class="col-2 navigation d-flex justify-content-center align-items-center" style="margin-top: 10vh;">
            <!-- navigation.blade.php -->

            <?php echo $__env->make('shared.category-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        </div>
        <div class="col d-flex justify-content-center align-items-center">
            <div class="product-container" style="padding-top: 50px;">
                <?php if(session('success')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <div class="row product-row" style="margin-left: 60px">
                    <div class="col">
                        <div class="row d-flex justify-content-between align-items-center mb-5">
                            
                            <?php if(isset($category)): ?>
                                <?php echo $__env->make('categories.' . $category, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/dashboard.blade.php ENDPATH**/ ?>