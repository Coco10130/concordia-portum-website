

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="/css/forgotpass.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center mb-5" style="font-family: 'oswald'; color: #ffffff;">Forgot your Password</h1>
    <p class="" style="color: #ffffff; font-family: 'oswald';" >Please enter your email address to recieve a verification code.</p>
    <?php echo $__env->make('auth.enter-email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.forgot-pass-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project file\app-crud\resources\views/forgot-password.blade.php ENDPATH**/ ?>